export type Code = number;

export type RequestOptions = {
  onSuccess?: () => void;
  onError?: () => void;
};
