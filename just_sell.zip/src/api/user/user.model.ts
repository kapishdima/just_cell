export type User = {
  pip: string;
  sh_name: string;
  email: string;
};
