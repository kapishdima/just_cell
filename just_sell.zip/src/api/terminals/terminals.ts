import { http } from "../client";
import { ApiRoutes } from "../routes";

export const getTerminalsList = async () => {
  const { data } = await http.get(ApiRoutes.TERMINALS_LIST);
  console.log(data);
};
