export enum ApiRoutes {
  LOGIN = "/UserAuth/",
  TERMINALS_LIST = "Terminals/List/",
  TEST = "/testSign.php",
}
