<template>
  <div class="table-actions">
    <img
      src="@/assets/icons/edit-icon.svg"
      alt="Edit"
      class="table-actions__icon"
    />
  </div>
</template>
<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({});
</script>
<style lang=""></style>
