<template>
  <router-link class="user-edit__link" :to="{ name: 'usersCreate' }">
    <img src="@/assets/icons/edit-icon.svg" alt="" />
    Редагувати
  </router-link>
</template>
<script lang="ts">
export default {};
</script>
<style lang=""></style>
