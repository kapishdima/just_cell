<template>
  <app-layout>
    <template #appTitle>Перегляд терміналів</template>
    <template #appContent>
      <terminal-table />
    </template>
  </app-layout>
</template>
<script>
import AppLayout from "@/components/layout/AppLayout/AppLayout.vue";
import TerminalTable from "@/components/terminals/TerminalTable.vue";
import { getTerminalsList } from "@/api/terminals/terminals";
export default {
  components: {
    AppLayout,
    TerminalTable,
  },

  mounted() {
    getTerminalsList();
  },
};
</script>
<style lang=""></style>
