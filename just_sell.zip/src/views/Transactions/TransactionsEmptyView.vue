<template lang="">
  <app-empty>
    <template #emptyTitle>У вас ще немає транзакцій</template>
  </app-empty>
</template>
<script>
import AppEmpty from "@/components/layout/AppLayout/AppEmpty.vue";
export default {
  components: {
    AppEmpty,
  },
};
</script>
<style lang=""></style>
