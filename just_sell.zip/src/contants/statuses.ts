export enum TransactionStatuses {
  REVERSED = "Транзакцію повернуто",
  SUCCESS = "Успішно",
}
