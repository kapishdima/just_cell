export enum ValidationMessages {
  PASSWORD_NOT_MATCH = "Паролі не співпадають",
  REQUIRED_FIELD = "Поле обов'язкове",
  MIN_NUMBER = "Значення повинно буде більше нуля",
}
