export const TERMINAL_STORAGE_KEY = "terminal";
export const RULES_STORAGE_KEY = "user_roles";
export const USER_STATE_KEY = "user";
export const TOKEN_STORE_KEY = "token";
export const MENU_STORE_KEY = "user_menu";
