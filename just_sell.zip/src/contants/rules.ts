export enum Rules {
  ADD_TERMINAL = "add_terminal",
  EDIT_TERMINAL = "edit_terminal",
  CHANGE_TRANSACTION_STATUS = "facq_transac_status_update",
  REVERSE_TRANSACTION = "facq_transac_reversal",
  REVERSE_TRANSACTION_SUM = "facq_transac_reversal_sum",
  ALL_OFFLINE_TERMINAL_UPDATE = "offline_all_update",
}
